package com.swp2.demo.entity;

public enum Member {
    FREE,
    VIP,
    PREMIUM
}
