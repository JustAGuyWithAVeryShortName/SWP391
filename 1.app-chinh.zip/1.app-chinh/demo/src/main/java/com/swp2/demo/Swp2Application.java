package com.swp2.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Swp2Application {

	public static void main(String[] args) {
		SpringApplication.run(Swp2Application.class, args);
	}

}
