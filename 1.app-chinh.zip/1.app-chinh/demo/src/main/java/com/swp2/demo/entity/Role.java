package com.swp2.demo.entity;

public enum Role {
    Guest,
    Member,
    Coach,
    Admin
}
